import { renderizarCatalogo } from "./src/cartaoProduto";
import { inicializarCarrinho } from "./src/menuCarrinho";

renderizarCatalogo();
inicializarCarrinho();
